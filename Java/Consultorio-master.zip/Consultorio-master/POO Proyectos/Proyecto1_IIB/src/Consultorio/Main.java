
package Consultorio;

import InterfazConsultorio.JFConectar;
import InterfazConsultorio.JFConsultorio;
public class Main {

 
    public static void main(String[] args) {
        JFConectar conectarBase = new JFConectar();
        conectarBase.setVisible(true);
    }
    
}
