package Fuentes;

import Interfacies.JFBiblioteca;

public class Main {

    
    public static void main(String[] args) {
      JFBiblioteca biblioteca = new JFBiblioteca();
      biblioteca.setVisible(true);
    }
    
}
